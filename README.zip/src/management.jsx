import React from 'react';
import Badcrumble from './common/badcrumble';

export default function Management() { 


    return (<>
        <Badcrumble  expressPath={['Dashboard/','Management',]}/>

        <h1>Management</h1>
     </>
    )
}