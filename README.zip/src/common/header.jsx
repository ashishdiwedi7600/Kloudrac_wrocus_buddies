import React from 'react';
import { Link, useNavigate } from 'react-router-dom'
import avatar from '../img/avatar.jpg'



export default function Header(){
    const navi = useNavigate();

    const routeChange = (e) => {
        e.preventDefault();
        navi('/');
      }
    const routeChange2 = (e) => {
        e.preventDefault();
        navi('/signup');
      }
  return <nav className="navbar navbar-expand-lg navbar-dark bg-dark nav ">
  <div className="container-fluid">
  <div className='nav-right' style={{ padding: '10px 50px 10px ', fontSize: '25px', justifyContent: 'start' }}>
                    <strong style={{ placeSelf: 'left', color: '#EEEEEE' }}>  FittyFreak</strong>
                </div><br />
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          
        </li>
        {/* <li className="nav-item">
          <a className="nav-link" href="#" onClick={routeChange2}>Sign up</a>
        </li> */}


      </ul>
      <div><h3 style={{color:'white',fontStyle:'initial',paddingLeft:'2.7vw'}}>Hello User </h3></div>
      
        <img src={avatar} style={{ borderRadius: '50%' }} className="img" />
        {/* <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" /> */}
        <a className="nav-link active" aria-current="page"  onClick={routeChange}>Logout</a>
      
    </div>
  </div>
</nav>
}