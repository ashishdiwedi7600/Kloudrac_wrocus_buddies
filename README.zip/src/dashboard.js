import React from 'react';
import image2 from './img/image2.jpg'
import gym3 from './img/gym3.jpg'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Header from './common/header';
import Sidemenu from './common/sidemenu';
import { Outlet } from 'react-router-dom'
import './dash.css'

export default function Dashboard() {

  const dashContainer = {
    position: 'absolute',
    left: '20vw',
    top: '8vh',
    backgroundImage: 'gym3'
  }


  return (<>
    <div style={{display:'flex',flexDirection:'column'}}>
      <div>
        <Header /></div>
      <div><Sidemenu /></div>
    </div>
    <div className='image' style={dashContainer}>

      <Outlet />

    </div>

  </>

  );
}

